//
//  ViewController.m
//  IBOutletIBaction
//
//  Created by Franti Saúl Huamán Mera on 3/15/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIAlertViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    
    self.primeroLabel.text = @"Are51.pe";
	// Do any additional setup after loading the view, typically from a nib.
}
- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)mostrar:(id)sender {
    //NSLog(@"Mostrar algo");
    UIAlertView *alert =[[UIAlertView alloc] initWithTitle:@"Alert View" message:@"mi primer Alert View" delegate:self cancelButtonTitle:@"Cancelar" otherButtonTitles:@"Papaya", @"Naranja", nil];
    alert.tag=1;
    [alert show];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag==1) {
        if (buttonIndex==1) {
            self.segundoLable.text = @"Papaya";
        }else{
            self.segundoLable.text= @"Naranja";
        }
        NSLog(@"Algún botón seleccionado");
    }
}
@end
