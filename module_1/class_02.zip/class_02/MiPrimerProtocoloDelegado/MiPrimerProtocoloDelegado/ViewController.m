//
//  ViewController.m
//  MiPrimerProtocoloDelegado
//
//  Created by Franti Saúl Huamán Mera on 3/22/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import "ViewController.h"
//Paso 4
#import "ControlViewController.h"

//Paso 5
@interface ViewController ()<ControlViewControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    ControlViewController *detalle = segue.destinationViewController;
    //Paso 7
    detalle.delegate = self;
}


//Paso 6
- (void)pasarColorSeleccionado:(UIColor *)color{
    self.view.backgroundColor = color;
}

@end
