//
//  ToolbarViewController.m
//  PracticaProtocoloDelegado
//
//  Created by Franti Saúl Huamán Mera on 3/29/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import "ToolbarViewController.h"

@interface ToolbarViewController ()

@end

@implementation ToolbarViewController

#pragma mark -
#pragma mark LifeCycle Methods
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewDidLoad{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark IBAction Methods
- (IBAction)atrasButton:(id)sender {
    [self.delegate pasarValor:sender deTextField:self.txtActual];
}
- (IBAction)adelanteButton:(id)sender {
    [self.delegate pasarValor:sender deTextField:self.txtActual];
}
- (IBAction)cerrarButton:(id)sender {
    [self.delegate pasarValor:sender deTextField:self.txtActual];
}
@end
