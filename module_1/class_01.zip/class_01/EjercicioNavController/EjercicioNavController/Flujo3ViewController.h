//
//  Flujo3ViewController.h
//  EjercicioNavController
//
//  Created by Franti Saúl Huamán Mera on 3/15/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Flujo3ViewController : UIViewController
- (IBAction)cerrarButton:(id)sender;

@end
