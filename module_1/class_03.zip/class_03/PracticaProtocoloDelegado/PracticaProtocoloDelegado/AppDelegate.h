//
//  AppDelegate.h
//  PracticaProtocoloDelegado
//
//  Created by Franti Saúl Huamán Mera on 3/29/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
