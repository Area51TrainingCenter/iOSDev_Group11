//
//  ViewController.m
//  PracticaProtocoloDelegado
//
//  Created by Franti Saúl Huamán Mera on 3/29/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import "ViewController.h"
#import "ToolbarViewController.h"


@interface ViewController ()<UITextFieldDelegate, ToolbarViewControllerDelegate>
@property (nonatomic, strong) ToolbarViewController *to;
@end

@implementation ViewController

#pragma mark -
#pragma mark LifeCycle Methods
- (void)viewDidLoad{
    [super viewDidLoad];
    
	// Do any additional setup after loading the view, typically from a nib.
}
- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark Text Field Delegate Methods
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    /*
    UIView *t = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 40)];
    t.backgroundColor= [UIColor blackColor];
    */
    self.to = [self.storyboard instantiateViewControllerWithIdentifier:@"miToolbar"];
    self.to.view.frame = CGRectMake(0, 0, 320, 44);
    self.to.delegate = self;
    self.to.txtActual = textField;
    [textField setInputAccessoryView:self.to.view];
    return YES;
}

#pragma mark -
#pragma mark Toolbar Delegate Method
- (void)pasarValor:(id)sender deTextField:(UITextField *)texF{
    UIBarButtonItem *b = (UIBarButtonItem *)sender;

    if ([b.title isEqualToString:@"<"]){
        if (texF == self.cajaTres){
            [self.cajaDos becomeFirstResponder];
        }else if (texF == self.cajaDos){
            [self.cajaUno becomeFirstResponder];
        }
    }else if ([b.title isEqualToString:@">"]){
        if (texF == self.cajaUno){
            [self.cajaDos becomeFirstResponder];
        }else if (texF == self.cajaDos){
            [self.cajaTres becomeFirstResponder];
        }
    }else{
        [texF resignFirstResponder];
    }
}
@end
