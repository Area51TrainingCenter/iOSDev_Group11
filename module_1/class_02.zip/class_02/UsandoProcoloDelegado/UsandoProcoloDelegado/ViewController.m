//
//  ViewController.m
//  UsandoProcoloDelegado
//
//  Created by Franti Saúl Huamán Mera on 3/22/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIAlertViewDelegate, UIActionSheetDelegate, UITextFieldDelegate>

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)mostrarAlertView:(id)sender {
    [[[UIAlertView alloc] initWithTitle:@"Alert View" message:@"Selecciona una opción" delegate:self cancelButtonTitle:@"Cancelar" otherButtonTitles:@"Aceptar ", nil] show];
}

- (IBAction)mostrarActionSheet:(id)sender {
    
    UIActionSheet *t = [[UIActionSheet alloc] initWithTitle:@"Action Sheet" delegate:self cancelButtonTitle:@"Cancelar" destructiveButtonTitle:@"Eliminar" otherButtonTitles:@"Opción 1", @"Opción 2", nil];
    [t showInView:self.view];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==0) {
        self.view.backgroundColor = [UIColor greenColor];
    }else if (buttonIndex==1){
        self.view.backgroundColor = [UIColor blackColor];
    }else{
        
    }
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"%i",buttonIndex);
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
@end
