//
//  ViewController.m
//  EjercicioProtocoloDelegado
//
//  Created by Franti Saúl Huamán Mera on 3/22/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import "ViewController.h"
//Paso 4
#import "DetalleViewController.h"

@interface ViewController ()<CualquierNombreParaElProtocolo>//Paso 5

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    DetalleViewController *de = segue.destinationViewController;
    de.cualquierNombreParaLaPropiedad = self;
}

//Paso 6
- (void)pasarCadenaConcatenada:(NSString *)cadenaUnica{
    self.textoAMostrar.text = cadenaUnica;
}

@end
