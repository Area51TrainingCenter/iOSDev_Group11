//
//  ViewController.m
//  Calc
//
//  Created by Franti Saúl Huamán Mera on 3/22/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIAlertViewDelegate, UITextFieldDelegate>

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)sumar:(id)sender {
    NSInteger resultado =[self.cajaUno.text integerValue]+[self.cajaDos.text integerValue];
    [self mostrarResultadoDeOperacion:@"SUMA" resultado:resultado];
}

- (IBAction)restar:(id)sender {
    NSInteger resultado =[self.cajaUno.text integerValue]-[self.cajaDos.text integerValue];
    [self mostrarResultadoDeOperacion:@"RESTA" resultado:resultado];
}

- (IBAction)multiplicar:(id)sender {
    NSInteger resultado =[self.cajaUno.text integerValue]*[self.cajaDos.text integerValue];
    [self mostrarResultadoDeOperacion:@"MULTIPLICACIÓN" resultado:resultado];
}

- (IBAction)dividir:(id)sender {
    NSInteger resultado =[self.cajaUno.text integerValue]/[self.cajaDos.text integerValue];
    [self mostrarResultadoDeOperacion:@"DIVISIÓN" resultado:resultado];
}


- (void)mostrarResultadoDeOperacion:(NSString *)operacion resultado:(NSInteger)res{
    [[[UIAlertView alloc] initWithTitle:operacion message:[NSString stringWithFormat:@"%i",res] delegate:self cancelButtonTitle:@"Cancelar" otherButtonTitles:@"Aceptar", nil] show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex==0) {
        self.view.backgroundColor = [UIColor lightGrayColor];
    }else{
        self.cajaUno.text = @"";
        self.cajaDos.text = @"";
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (textField == self.cajaUno) {
        [self.cajaDos becomeFirstResponder];
    }else{
        [self.cajaDos resignFirstResponder];
    }
    return YES;
}
@end
