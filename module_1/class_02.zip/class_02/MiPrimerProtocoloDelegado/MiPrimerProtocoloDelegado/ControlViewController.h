//
//  ControlViewController.h
//  MiPrimerProtocoloDelegado
//
//  Created by Franti Saúl Huamán Mera on 3/22/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import <UIKit/UIKit.h>
//Paso 1
@protocol ControlViewControllerDelegate <NSObject>
@required
- (void)pasarColorSeleccionado:(UIColor *)color;

@optional
- (void)metodoOpcionalNoEsObligatiorioDeImplementar;

@end

@interface ControlViewController : UIViewController

//Paso 2
@property (nonatomic, weak) id<ControlViewControllerDelegate>delegate;

- (IBAction)pintarDeAzul:(id)sender;
- (IBAction)pintarDeVerde:(id)sender;
- (IBAction)pintarDeRojo:(id)sender;

@end
