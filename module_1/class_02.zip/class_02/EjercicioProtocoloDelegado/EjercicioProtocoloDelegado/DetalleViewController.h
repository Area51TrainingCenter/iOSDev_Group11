//
//  DetalleViewController.h
//  EjercicioProtocoloDelegado
//
//  Created by Franti Saúl Huamán Mera on 3/22/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import <UIKit/UIKit.h>

//Paso 1
@protocol CualquierNombreParaElProtocolo <NSObject>
-(void)pasarCadenaConcatenada:(NSString *)cadenaUnica;
@end

@interface DetalleViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *cajaUno;
@property (weak, nonatomic) IBOutlet UITextField *cajaDos;
- (IBAction)juntar:(id)sender;

//Paso 2
@property (nonatomic, weak) id<CualquierNombreParaElProtocolo>cualquierNombreParaLaPropiedad;

@end
