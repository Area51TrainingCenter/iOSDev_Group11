//
//  FHFinViewController.h
//  PrimeraClase
//
//  Created by Franti Saúl Huamán Mera on 3/15/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FHFinViewController : UIViewController
- (IBAction)cerrarModal:(id)sender;

@end
