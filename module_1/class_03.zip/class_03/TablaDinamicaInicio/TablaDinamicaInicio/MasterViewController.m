//
//  MasterViewController.m
//  TablaDinamicaInicio
//
//  Created by Franti Saúl Huamán Mera on 3/29/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import "MasterViewController.h"

@interface MasterViewController ()

@end

@implementation MasterViewController

#pragma mark -
#pragma mark LifeCycle Methods
- (id)initWithStyle:(UITableViewStyle)style{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewDidLoad{
    [super viewDidLoad];
}
- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

#pragma mark -
#pragma mark - Table View Data Source Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0){
        return 2;
    }else{
        return 1;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0){
        if(indexPath.row==0){
            UITableViewCell *cell =
            [tableView dequeueReusableCellWithIdentifier:@"basic" forIndexPath:indexPath];
            cell.textLabel.text = @"Estilo Básico";
            return cell;
        }else{
            UITableViewCell *rt = [tableView dequeueReusableCellWithIdentifier:@"left" forIndexPath:indexPath];
            rt.textLabel.text = @"Princial";
            rt.detailTextLabel.text = @"Secundario";
            return rt;
        }
    }else{
        UITableViewCell *we = [tableView dequeueReusableCellWithIdentifier:@"subtitle" forIndexPath:indexPath];
        we.textLabel.text = @"Area51";
        we.detailTextLabel.text = @"hola mundo";
        return we;
    }
    
    

}
@end
