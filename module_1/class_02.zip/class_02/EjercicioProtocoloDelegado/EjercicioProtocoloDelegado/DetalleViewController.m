//
//  DetalleViewController.m
//  EjercicioProtocoloDelegado
//
//  Created by Franti Saúl Huamán Mera on 3/22/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import "DetalleViewController.h"

@interface DetalleViewController ()

@end

@implementation DetalleViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)juntar:(id)sender {
    //Paso 3
    /*
    NSString *cadenaNueva = [NSString stringWithFormat:@"%@ %@",self.cajaUno.text, self.cajaDos.text];
    [self.cualquierNombreParaLaPropiedad pasarCadenaConcatenada:cadenaNueva];*/
    
    [self.cualquierNombreParaLaPropiedad pasarCadenaConcatenada:[NSString stringWithFormat:@"%@ %@",self.cajaUno.text, self.cajaDos.text]];
    
    [self.navigationController popViewControllerAnimated:YES];
    //Volver al papá
}
@end
