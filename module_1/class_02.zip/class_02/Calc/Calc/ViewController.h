//
//  ViewController.h
//  Calc
//
//  Created by Franti Saúl Huamán Mera on 3/22/14.
//  Copyright (c) 2014 Franti Saúl Huamán Mera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *cajaUno;
@property (weak, nonatomic) IBOutlet UITextField *cajaDos;
- (IBAction)sumar:(id)sender;
- (IBAction)restar:(id)sender;
- (IBAction)multiplicar:(id)sender;
- (IBAction)dividir:(id)sender;


@end
